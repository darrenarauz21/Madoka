# Madoka Scanner

Extensión para Edge, Chrome y Firefox que analiza cada descarga con IA (Google Magika).
El instalador `madoka.py` registra el servidor como servicio del sistema en cualquier SO.

---

## Instalación

### Windows
```powershell
python madoka.py
```
> Para registrarlo como servicio real, abre PowerShell **como Administrador**.
> Sin admin también funciona: se agrega al inicio de sesión del usuario.

### macOS
```bash
python3 madoka.py
```

### Linux
```bash
python3 madoka.py
```

---

## Cargar la extensión en cada navegador

### Chrome / Edge
1. Abre `chrome://extensions/` o `edge://extensions/`
2. Activa **Modo desarrollador**
3. Clic en **Cargar sin empaquetar**
4. Selecciona la carpeta **`extension/`**

### Firefox
1. Abre `about:debugging`
2. Clic en **Este Firefox**
3. Clic en **Cargar complemento temporal**
4. Selecciona el archivo **`extension-firefox/manifest.json`**

> Para instalación permanente en Firefox necesitas firmar la extensión en
> [addons.mozilla.org](https://addons.mozilla.org/developers/) o usar Firefox Developer Edition.

### Safari
Safari requiere conversión con Xcode en macOS:
```bash
xcrun safari-web-extension-converter extension/ --project-location ~/Desktop --app-name "MadokaScanner"
```
Luego abre el proyecto en Xcode y ejecútalo. Solo disponible en Mac con Xcode instalado.

---

## Comandos de madoka.py

```bash
python madoka.py              # instalar y registrar como servicio
python madoka.py status       # ver si el servidor está corriendo
python madoka.py start        # iniciar el servidor
python madoka.py stop         # detener el servidor
python madoka.py remove       # desinstalar completamente
```

Verificar manualmente en el navegador:
```
http://localhost:5050/ping
```

---

## Puerto personalizado

```bash
MADOKA_PORT=5051 python madoka.py
```

---

## Desinstalar

```bash
python madoka.py remove
```
